#!/bin/bash

echo "Criando as imagens ...."

docker build -t fhorn/projeto-backend:1.0 backend/.
docker build -t fhorn/projeto-database:1.0 database/.

echo "Realizando push das imagens ...."

docker push /projeto-backend:1.0 backend/.
docker push fhorn/projeto-database:1.0 database/.

echo "Criando serviços no cluster kubernetes ...."

kubectl apply -f ./services.yml

echo "Criando deployments ...."

kubectl apply -f ./deployment.yml

echo "FIM"